﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment4_webdev.v2.Models
{
    public class Industry
    {
        public int IndustryId { get; set; }
        [DisplayName("Name")]
        [Required(ErrorMessage = "Name is required")]
        [StringLength(20, MinimumLength = 5, ErrorMessage = "Please enter a valid name")]
        public string Name { get; set; }
        [DisplayName("Candidates")]
        public List<Candidate> Candidates { get; set; }
        [DisplayName("Comapnies")]
        public List<Company> Companies { get; set; }
        [DisplayName("Sector")]
        [Required(ErrorMessage = "Sector is required")]
        [StringLength(20, MinimumLength = 5, ErrorMessage = "Please enter a valid sector")]
        public string Sector { get; set; }

    }

}
