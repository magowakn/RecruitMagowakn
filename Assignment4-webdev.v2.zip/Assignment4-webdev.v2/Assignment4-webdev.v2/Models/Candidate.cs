﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment4_webdev.v2.Models
{
    public class Candidate
    {
        public int CandidateId { get; set; }
        [DisplayName("First")]
        [Required(ErrorMessage = "Firt Name is required")]
        [StringLength(20, MinimumLength = 5, ErrorMessage = "Please enter a valid first name")]
        public string FirstName { get; set; }
        [DisplayName("Last")]
        [Required(ErrorMessage = "Last Name is required")]
        [StringLength(20, MinimumLength = 5, ErrorMessage = "Please enter a valid last name")]
        public string LastName { get; set; }
        [DisplayName("Target Salary")]
        [Range(5000,500000)]
        public decimal TargetSalary { get; set; }

        [DisplayName("Full Name")]
        [StringLength(20, MinimumLength = 5, ErrorMessage = "Please enter a valid Full Name")]

        public string FullName
        {
            get { return FirstName + " " + LastName; }
        }

        [DisplayName("Start Date")]
        [DataType(DataType.Date)]
        public DateTime? StartDate { get; set; }
        [DisplayName("Company")]
        public Company Company { get; set; }
        [DisplayName("Company ID")]
        public int CompanyId { get; set; }
        [DisplayName("Job Title")]
        public JobTitle JobTitle { get; set; }
        [DisplayName("Job Title ID")]
        public int JobTitleId { get; set; }
        [DisplayName("Industry")]
        public Industry Industry { get; set; }
        [DisplayName("Industry ID")]
        public int IndustryId { get; set; }
        [DisplayName("Years Experience")]
        [Range(0, 40)]
        public int YearsExperience { get; set; }

    }

}
