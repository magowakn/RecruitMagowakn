﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment4_webdev.v2.Models
{
    public class Company
    {
        public int CompanyId { get; set; }
        [DisplayName("Name")]
        [Required(ErrorMessage = "Name is required")]
        [StringLength(20, MinimumLength = 5, ErrorMessage = "Please enter a valid name")]
        public string Name { get; set; }
        [DisplayName("Desired Position")]
        [Required(ErrorMessage = "Desired Position is required")]
        [StringLength(20, MinimumLength = 5, ErrorMessage = "Please enter a valid position")]
        public string DesiredPosition { get; set; }
        [DisplayName("Minimum Salary")]
        [Range(50000, 500000)]
        public decimal MinSalary { get; set; }
        [DisplayName("Maximum Salary")]
        [Range(50000,500000)]
        [RegularExpression("Salary Cap is 500k")]
        public decimal MaxSalary { get; set; }
        [DisplayName("Start Date")]
        [DataType(DataType.Date)]
        public DateTime? StartDate { get; set; }
        [DisplayName("Candidates")]
        public List<Candidate> Candidate { get; set; }
        [DisplayName("Industry")]
        public Industry Industry { get; set; }
        [DisplayName("Industry ID")]
        public int IndustryId { get; set; }
        [DisplayName("Location")]
        [Required(ErrorMessage = "Location is required")]
        [StringLength(20, MinimumLength = 5, ErrorMessage = "Please enter a valid location")]
        public string Location { get; set; }
        [DisplayName("Established")]
        [DataType(DataType.Date)]
        public DateTime Established { get; set; }
        [DisplayName("Annual Revenue in $ millions")]
        [Range(0, 100000)]
        public decimal AnnualRevenue { get; set; }
        [DisplayName("Public")]
        public bool Public { get; set; }

    }

}
