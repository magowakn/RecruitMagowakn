﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment4_webdev.v2.Models
{
    public class JobTitle
    {
        public int JobTitleId { get; set; }
        [DisplayName("Title")]
        [Required(ErrorMessage = "Title is required")]
        [StringLength(20, MinimumLength =5, ErrorMessage ="Please enter a valid title")]
        public string Title { get; set; }
        [DisplayName("Minimum Salary")]
        [Range(50000, 500000)]
        public decimal MinSalary { get; set; }
        [DisplayName("Maximum Salary")]
        [Range(50000, 500000)]
        [RegularExpression("Salary Cap is 500k")]
        public decimal MaxSalary { get; set; }
        [DisplayName("Candidates")]
        public List<Candidate> Candidates { get; set; }

    }

}
