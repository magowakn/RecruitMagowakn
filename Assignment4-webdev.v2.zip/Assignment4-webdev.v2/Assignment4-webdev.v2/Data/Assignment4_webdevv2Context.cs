﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Assignment4_webdev.v2.Models;

namespace Assignment4_webdev.v2.Data
{
    public class Assignment4_webdevv2Context : DbContext
    {
        public Assignment4_webdevv2Context (DbContextOptions<Assignment4_webdevv2Context> options)
            : base(options)
        {
        }

        public DbSet<Assignment4_webdev.v2.Models.Candidate> Candidate { get; set; }

        public DbSet<Assignment4_webdev.v2.Models.Company> Company { get; set; }

        public DbSet<Assignment4_webdev.v2.Models.Industry> Industry { get; set; }

        public DbSet<Assignment4_webdev.v2.Models.JobTitle> JobTitle { get; set; }
    }
}
