﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Assignment4_webdev.v2.Data;
using Assignment4_webdev.v2.Models;

namespace Assignment4_webdev.v2.Pages.Candidates
{
    public class IndexModel : PageModel
    {
        private readonly Assignment4_webdev.v2.Data.Assignment4_webdevv2Context _context;

        public IndexModel(Assignment4_webdev.v2.Data.Assignment4_webdevv2Context context)
        {
            _context = context;
        }

        public IList<Candidate> Candidate { get;set; }

        public async Task OnGetAsync()
        {
            Candidate = await _context.Candidate
                .Include(c => c.Company)
                .Include(c => c.Industry)
                .Include(c => c.JobTitle).ToListAsync();
        }
    }
}
